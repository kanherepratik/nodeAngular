angular.module('mainController', []).controller('mainController', function($scope) {

	$scope.test = "it worked";

});