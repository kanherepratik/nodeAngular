var app = angular.module('sampleApp', ['ngRoute', 'mainController']);

app.config(['$routeProvider', '$locationProvider', function($routeProvider, $locationProvider) {

	$routeProvider
		// home page
		.when('/', {
			templateUrl: 'app/mainModule/home.html',
			controller: 'mainController'
		});

	$locationProvider.html5Mode(true);

}]);